package main.scala.schema.barometer

// Defining case class for Schema from 1859 to 1861
case class BarometerDataSchema1859To1861(year:String, month:String, day:String, mBaro:String, mBaroTemp:String, 
    mAirPressure:String, nBaro:String, nBaroTemp:String,nAirPressure:String, eBaro:String, eBaroTemp:String,eAirPressure:String)
