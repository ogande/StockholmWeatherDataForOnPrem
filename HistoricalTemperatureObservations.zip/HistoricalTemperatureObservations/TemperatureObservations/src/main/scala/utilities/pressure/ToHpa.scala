package main.scala.utilities.pressure

import main.scala.utilities.custom

//Defining a class for the inches conversion to hpa 
class ToHpa(data:String) {
  // Description // OP
  def convert = custom.doublePrecision((data.toDouble/10.toDouble)*33.86389.toDouble).toString()
  def convertFromInch = custom.doublePrecision(data.toDouble*33.86389.toDouble).toString()
}
